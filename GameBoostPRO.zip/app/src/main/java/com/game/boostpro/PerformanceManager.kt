
package com.game.boostpro

import android.app.ActivityManager
import android.content.Context
import android.view.Window

object PerformanceManager {
    fun optimizeSystem(context: Context) {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        am.runningAppProcesses?.forEach {
            if (it.importance > ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND)
                am.killBackgroundProcesses(it.processName)
        }
    }
    fun unlock120Hz(window: Window) {
        window.setPreferredRefreshRate(120f)
    }
}
