
package com.game.boostpro

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnBoost).setOnClickListener { PerformanceManager.optimizeSystem(this) }
        findViewById<Button>(R.id.btn120).setOnClickListener { PerformanceManager.unlock120Hz(window) }
        findViewById<Button>(R.id.btnTouch).setOnClickListener { TouchBoost.apply(this) }
        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            startService(Intent(this, FPSOverlay::class.java))
        }
    }
}
