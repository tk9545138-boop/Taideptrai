
package com.game.boostpro

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class FPSOverlay : Service() {
    private lateinit var fpsText: TextView

    override fun onCreate() {
        super.onCreate()

        fpsText = TextView(this).apply {
            text = "FPS: --"
            setTextColor(0xFF00E5FF.toInt())
            textSize = 16f
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        params.gravity = Gravity.TOP or Gravity.RIGHT
        params.y = 100

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm.addView(fpsText, params)
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
