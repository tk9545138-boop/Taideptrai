
package com.game.boostpro

import android.content.Context
import android.provider.Settings

object TouchBoost {
    fun apply(context: Context) {
        Settings.System.putInt(context.contentResolver, "touch_sampling_rate", 2)
    }
}
